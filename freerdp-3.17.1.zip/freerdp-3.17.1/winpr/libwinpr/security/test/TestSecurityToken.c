
#include <winpr/crt.h>
#include <winpr/tchar.h>
#include <winpr/security.h>

int TestSecurityToken(int argc, char* argv[])
{
	return 0;
}
