
#include <winpr/crt.h>
#include <winpr/pool.h>

int TestPoolSynch(int argc, char* argv[])
{
	return 0;
}
